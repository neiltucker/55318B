# Local Environment Setup Package

**Course:** Advanced Automated Administration With PowerShell  
**Course number:** 55318B  
**Setup profile:** Hyper-V Virtual Machine  
**OS target:** windows  
**Generated:** 2026-06-11T17:51:30.895Z  
**Documentation version:** 2026-06-10.update33.v1

## Hardware requirements

### Minimum

| Field | Value |
|---|---|
| CPU cores | 4 |
| RAM GB | 8 |
| Disk GB | 80 |
| Virtualization required | Yes |
| Admin rights required | Yes |
| Internet required | Yes |

### Recommended

| Field | Value |
|---|---|
| CPU cores | 6 |
| RAM GB | 16 |
| Disk GB | 120 |
| Virtualization required | Yes |
| Admin rights required | Yes |
| Internet required | Yes |

### Hardware notes

- SQL Server courses usually need additional disk and memory for database samples and restore files.
- Local virtualization support must be enabled in firmware and Windows features.
- Docker requires local container runtime support and suitable file-share permissions.
- Use the recommended memory/disk values when AdventureWorks or similar sample databases are required.

## Required software

- Windows or Windows Server matching the approved course requirements
- Linux distribution matching the approved course requirements
- Docker Desktop or Docker Engine
- Hyper-V feature enabled on the local host
- PowerShell 7 or Windows PowerShell as required by the course
- SQL Server edition and tooling approved by the course owner
- SQL Server Management Studio or approved SQL client
- Node.js LTS and npm
- Git client
- Visual Studio Code

## Required tools

- bash
- sudo
- apt/yum/dnf as applicable
- PowerShell
- sqlcmd
- docker
- docker compose
- npm
- git

## Network requirements

| Field | Value |
|---|---|
| Internet required | Yes |
| Required ports | 1433, 3000, 8085, 9999 |
| Required domains | None specified |
