# Local Environment Setup Package

**Course:** Advanced Automated Administration With PowerShell  
**Course number:** 55318B  
**Setup profile:** Hyper-V Virtual Machine  
**OS target:** windows  
**Generated:** 2026-06-11T17:51:30.896Z  
**Documentation version:** 2026-06-10.update33.v1

## Student setup checklist

- [ ] Review any licensing or subscription requirements supplied by your organization or instructor.
- [ ] Confirm your local computer or VM meets the minimum hardware requirements.
- [ ] Confirm the required course files are present in the class files folder.
- [ ] Confirm required software is installed before the first lab.
- [ ] Confirm required command-line tools can be opened.
- [ ] Confirm you can create or write to the approved lab and validation folders.
- [ ] Confirm internet access is available if required by the course.
- [ ] Report any missing software, blocked ports, or access-denied errors before class begins.

## Student-visible local paths

| Field | Value |
|---|---|
| Class files folder | C:\Classfiles\Classfiles |
| Lab files folder | C:\Classfiles\Labs |
| Validation logs folder | C:\Classfiles\ValidationLogs |
| Guest OS class files path | C:\Classfiles |
