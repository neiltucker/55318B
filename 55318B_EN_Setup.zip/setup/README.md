# Local Environment Setup Package

**Course:** Advanced Automated Administration With PowerShell  
**Course number:** 55318B  
**Setup profile:** Hyper-V Virtual Machine  
**OS target:** windows  
**Generated:** 2026-06-11T17:51:30.895Z  
**Documentation version:** 2026-06-10.update33.v1

## Purpose

This package includes approved local setup documentation plus local-only setup, validation, and reset assets where appropriate for the approved setup profile. Generated scripts are intentionally conservative: they create folders, validate prerequisites, and provide local setup scaffolding without licensing bypass, activation, embedded credentials, or cloud provisioning.

## How to use this ZIP

Download and extract this ZIP on the instructor, classroom setup, or student preparation machine. Courseware Studio does not write files directly to the local computer. The paths in this package are approved target locations for setup instructions, generated scripts, validation logs, Docker resources, or Hyper-V resources. Review the included licensing notice and README before running any generated asset.

## Approved setup contract

| Field | Value |
|---|---|
| Environment type | Hyper-V Virtual Machine |
| Local-only setup | Yes |
| Cloud deployment excluded | Yes |
| Validation requested | Yes |
| Executable scripts requested | Yes |
| Cleanup/reset requested | No |
| Approved at | 2026-06-11T17:51:30.815Z |

## Included documentation

- requirements.md
- licensing_notice.md
- path_layout.md
- instructor_preflight_checklist.md
- student_setup_checklist.md
- validation/manual_validation_checklist.md

## Local-only boundary

- Excluded: azure_vm
- Excluded: aws
- Excluded: google_cloud
- Excluded: cloud_deployment_scripts
- Excluded: terraform
- Excluded: bicep
- Excluded: arm_templates
- Excluded: cloudformation
- Excluded: cloud_init
- Excluded: hosted_lab_orchestration

## Safety controls

- No cloud provisioning templates are generated.
- No software activation or license bypass steps are generated.
- No credentials, product keys, tokens, or secrets are embedded.
- Cleanup/reset assets avoid destructive data removal by default.
- Scripts are generated only after the setup contract is approved.

## Next step

Run the validation script/checklist first, review the generated script comments, and execute setup actions only on an approved local machine or local VM prepared for this course.
