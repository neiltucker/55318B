# Hyper-V VM Configuration Checklist

- [ ] Hyper-V is enabled on the local host.
- [ ] Hardware virtualization is enabled in firmware.
- [ ] Local admin rights are available.
- [ ] Licensed guest OS media is available.
- [ ] VM folder exists or can be created: C:\Hyper-V\55318B\VMs
- [ ] Export/checkpoint folder exists or can be created: C:\Hyper-V\55318B\Checkpoints
- [ ] Guest class files path is planned: C:\Classfiles
- [ ] Minimum RAM/CPU/disk requirements are satisfied.
- [ ] Networking is local or NAT-based and does not imply cloud deployment.
- [ ] A checkpoint/export plan is approved before class.
