# Courseware Studio Hyper-V Local VM Helper
# Local-only. No cloud provisioning. No activation. No embedded credentials.

[CmdletBinding(SupportsShouldProcess=$true)]
param(
  [string]$VmName = '55318B',
  [string]$VmPath = 'C:\Hyper-V\55318B\VMs',
  [UInt64]$MemoryStartupBytes = 16GB,
  [switch]$CreateVm
)

$ErrorActionPreference = 'Stop'
Write-Host 'Courseware Studio Hyper-V local helper' -ForegroundColor Cyan
Write-Host 'This script does not supply guest OS media, licenses, product keys, or cloud resources.' -ForegroundColor Yellow

New-Item -Path $VmPath -ItemType Directory -Force | Out-Null

if (-not (Get-Command Get-VM -ErrorAction SilentlyContinue)) {
  throw 'Hyper-V PowerShell cmdlets are not available. Enable Hyper-V before using this helper.'
}

if (-not $CreateVm) {
  Write-Host 'Preview mode only. Re-run with -CreateVm after reviewing the script and confirming local Hyper-V requirements.' -ForegroundColor Yellow
  Write-Host "Planned VM: $VmName"
  Write-Host "Planned path: $VmPath"
  Write-Host "Memory startup bytes: $MemoryStartupBytes"
  exit 0
}

if (Get-VM -Name $VmName -ErrorAction SilentlyContinue) {
  Write-Host "VM already exists: $VmName" -ForegroundColor Green
} elseif ($PSCmdlet.ShouldProcess($VmName, 'Create local Hyper-V VM shell without cloud resources')) {
  New-VM -Name $VmName -Generation 2 -MemoryStartupBytes $MemoryStartupBytes -Path $VmPath -NoVHD | Out-Null
  Write-Host "VM shell created: $VmName" -ForegroundColor Green
  Write-Host 'Attach properly licensed storage/install media manually before class.' -ForegroundColor Yellow
}
