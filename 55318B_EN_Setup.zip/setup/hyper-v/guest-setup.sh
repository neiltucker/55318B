#!/usr/bin/env bash
set -euo pipefail

# Courseware Studio Local Environment Setup
# Local-only: this script does not provision cloud resources.
# Licensing: I understand that I am responsible for all software licensing, activation, subscriptions, usage rights, and compliance with vendor license terms for any software used in this setup package. Courseware Studio may provide local setup guidance, scripts, and validation checks, but it does not provide software licenses or cloud deployment rights.

REQUIRED_PATHS=('C:\Classfiles\' 'C:\Classfiles\Classfiles' 'C:\Classfiles\Downloads' 'C:\Classfiles\Labs' 'C:\Classfiles\Scripts' 'C:\Classfiles\ValidationLogs' 'C:\Hyper-V\55318B\VMs' 'C:\Hyper-V\55318B\Checkpoints' 'C:\Classfiles')
REQUIRED_TOOLS=('bash' 'sudo' 'apt/yum/dnf as applicable' 'PowerShell' 'sqlcmd' 'docker' 'docker compose' 'npm' 'git')
VALIDATION_LOG_FOLDER='C:\Classfiles\ValidationLogs'

echo 'Courseware Studio local setup script'
echo 'This script creates approved local folders and checks required command-line tools.'
echo 'It does not install licensed software, activate products, embed credentials, or provision cloud resources.'

for path in "${REQUIRED_PATHS[@]}"; do
  [[ -z "$path" ]] && continue
  mkdir -p "$path"
  echo "Folder ready: $path"
done

mkdir -p "$VALIDATION_LOG_FOLDER"
TOOL_LOG="$VALIDATION_LOG_FOLDER/setup_tool_check.txt"
: > "$TOOL_LOG"
missing=0
for tool in "${REQUIRED_TOOLS[@]}"; do
  if command -v "$tool" >/dev/null 2>&1; then
    echo "$tool: found" | tee -a "$TOOL_LOG"
  else
    echo "$tool: missing" | tee -a "$TOOL_LOG"
    missing=1
  fi
done

if [[ "$missing" -ne 0 ]]; then
  echo 'One or more tools are missing. Install required software only from approved/vendor-authorized sources.' >&2
fi

echo 'Local setup preparation complete. Run the validation script before class.'
