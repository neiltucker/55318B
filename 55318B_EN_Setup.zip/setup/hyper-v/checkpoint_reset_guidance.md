# Hyper-V Checkpoint and Reset Guidance

Use Hyper-V checkpoints or exports only after confirming licensing and classroom policy. This package does not automatically revert or delete VMs.
