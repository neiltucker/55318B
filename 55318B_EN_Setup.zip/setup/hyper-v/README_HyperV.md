# Hyper-V Local Virtual Machine Setup

This folder contains local Hyper-V setup guidance and conservative helper scripts generated from the approved setup contract.

## Intended VM

- Suggested VM name: 55318B
- VM folder: C:\Hyper-V\55318B\VMs
- Checkpoint/export folder: C:\Hyper-V\55318B\Checkpoints
- Guest class files path: C:\Classfiles

## Safety notes

- Local Hyper-V only.
- No Azure, AWS, Google Cloud, or hosted lab orchestration is configured.
- The VM helper script runs in preview mode unless explicitly invoked with the creation flag.
- You must supply your own properly licensed ISO/VHDX/install media.
