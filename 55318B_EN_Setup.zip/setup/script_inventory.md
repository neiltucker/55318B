# Generated Script and Asset Inventory

This file lists setup assets generated from the approved local setup contract. Review each script before use.

## Safety boundary

- Local setup only.
- No cloud provisioning.
- No activation or license bypass.
- No embedded credentials or secrets.
- No destructive reset by default.

## Generated files

- setup/README.md
- setup/requirements.md
- setup/licensing_notice.md
- setup/path_layout.md
- setup/instructor_preflight_checklist.md
- setup/student_setup_checklist.md
- setup/validation/manual_validation_checklist.md
- setup/package_manifest.json
- setup/package_verification.md
- setup/Environment_Requirements.json
- setup/hyper-v/README_HyperV.md
- setup/hyper-v/VM_Configuration_Checklist.md
- setup/hyper-v/create-local-vm.ps1
- setup/hyper-v/guest-setup.sh
- setup/validation/validate-hyperv.ps1
- setup/hyper-v/checkpoint_reset_guidance.md

## Approved setup profile

- Environment type: hyperv_vm
- OS target: windows
- Validation requested: yes
- Cleanup/reset requested: no

## Licensing notice

I understand that I am responsible for all software licensing, activation, subscriptions, usage rights, and compliance with vendor license terms for any software used in this setup package. Courseware Studio may provide local setup guidance, scripts, and validation checks, but it does not provide software licenses or cloud deployment rights.
