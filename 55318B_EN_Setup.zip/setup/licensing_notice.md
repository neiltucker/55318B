# Local Environment Setup Package

**Course:** Advanced Automated Administration With PowerShell  
**Course number:** 55318B  
**Setup profile:** Hyper-V Virtual Machine  
**OS target:** windows  
**Generated:** 2026-06-11T17:51:30.896Z  
**Documentation version:** 2026-06-10.update33.v1

## Licensing responsibility notice

I understand that I am responsible for all software licensing, activation, subscriptions, usage rights, and compliance with vendor license terms for any software used in this setup package. Courseware Studio may provide local setup guidance, scripts, and validation checks, but it does not provide software licenses or cloud deployment rights.

## Warning metadata

| Field | Value |
|---|---|
| Warning version | 2026-06-10.v1 |
| Licensing notice required | Yes |
| Local-only setup | Yes |
| Cloud deployment excluded | Yes |

## Explicit non-inclusions

This package does not provide licenses, subscriptions, activation keys, bypass procedures, cloud deployment rights, credentials, or vendor entitlement decisions.
