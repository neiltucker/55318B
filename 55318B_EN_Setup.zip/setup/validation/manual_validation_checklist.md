# Local Environment Setup Package

**Course:** Advanced Automated Administration With PowerShell  
**Course number:** 55318B  
**Setup profile:** Hyper-V Virtual Machine  
**OS target:** windows  
**Generated:** 2026-06-11T17:51:30.896Z  
**Documentation version:** 2026-06-10.update33.v1

## Manual validation checklist

This checklist complements the generated validation script. Review both before class.

- [ ] Operating system matches the approved target: **windows**.
- [ ] Minimum CPU/RAM/disk requirements are satisfied.
- [ ] Required software is installed and opens successfully.
- [ ] Required tools are available from the expected terminal or shell.
- [ ] Required ports are available or intentionally reserved for course services.
- [ ] Required domains are reachable when internet access is required.
- [ ] Root setup folder exists.
- [ ] Class files folder exists.
- [ ] Downloads/installers folder exists or approved offline installers are available.
- [ ] Lab files folder exists and contains expected course resources.
- [ ] Validation logs folder exists and is writable.
- [ ] Docker folders/volume paths are checked if Docker is the approved profile.
- [ ] Hyper-V folders/checkpoints/guest paths are checked if Hyper-V is the approved profile.
- [ ] No cloud deployment/provisioning scripts are present in this package.

## Required ports

- 1433
- 3000
- 8085
- 9999

## Required domains

- No required domains were specified.
