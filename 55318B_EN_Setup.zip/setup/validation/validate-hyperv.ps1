# Courseware Studio Hyper-V Validation
# Local-only validation. No cloud checks are performed.

$VmName = '55318B'
$VmPath = 'C:\Hyper-V\55318B\VMs'
$ExportPath = 'C:\Hyper-V\55318B\Checkpoints'

$Results = New-Object System.Collections.Generic.List[object]
$Results.Add([pscustomobject]@{ Check = 'hyperv_cmdlets_available'; Target = 'Get-VM'; Passed = [bool](Get-Command Get-VM -ErrorAction SilentlyContinue) })
$Results.Add([pscustomobject]@{ Check = 'vm_folder_exists'; Target = $VmPath; Passed = (Test-Path $VmPath) })
$Results.Add([pscustomobject]@{ Check = 'export_folder_exists'; Target = $ExportPath; Passed = (Test-Path $ExportPath) })
try {
  $Vm = Get-VM -Name $VmName -ErrorAction Stop
  $Results.Add([pscustomobject]@{ Check = 'vm_exists'; Target = $VmName; Passed = $true })
  $Results.Add([pscustomobject]@{ Check = 'vm_state_review'; Target = $Vm.State; Passed = $true })
} catch {
  $Results.Add([pscustomobject]@{ Check = 'vm_exists'; Target = $VmName; Passed = $false })
}
$Results | Format-Table -AutoSize
$Failed = @($Results | Where-Object { -not $_.Passed })
if ($Failed.Count -gt 0) { exit 1 }
