# Setup Package Verification Manifest

**Package:** Local Environment Setup Package  
**Mode:** full_package  
**Generated:** 2026-06-11T17:51:30.895Z  
**Version:** 2026-06-10.update31.v1

## Inventory summary

| Check | Value |
|---|---:|
| File count | 17 |
| Executable scripts included | Yes |
| Validation scripts generated | Yes |
| Docker files generated | No |
| Hyper-V files generated | Yes |
| Cloud script/path matches | 0 |

## Safety verification

- Local-only flag: Pass
- Cloud deployment excluded: Pass
- Licensing warning included: Pass
- Cloud scripts absent: Pass
- Credentials embedded: No
- Activation or license bypass included: No
- Destructive cleanup by default: No

## Files

- setup/Environment_Requirements.json
- setup/hyper-v/checkpoint_reset_guidance.md
- setup/hyper-v/create-local-vm.ps1
- setup/hyper-v/guest-setup.sh
- setup/hyper-v/README_HyperV.md
- setup/hyper-v/VM_Configuration_Checklist.md
- setup/instructor_preflight_checklist.md
- setup/licensing_notice.md
- setup/package_manifest.json
- setup/package_verification.md
- setup/path_layout.md
- setup/README.md
- setup/requirements.md
- setup/script_inventory.md
- setup/student_setup_checklist.md
- setup/validation/manual_validation_checklist.md
- setup/validation/validate-hyperv.ps1
