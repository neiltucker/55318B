# Local Environment Setup Package

**Course:** Advanced Automated Administration With PowerShell  
**Course number:** 55318B  
**Setup profile:** Hyper-V Virtual Machine  
**OS target:** windows  
**Generated:** 2026-06-11T17:51:30.896Z  
**Documentation version:** 2026-06-10.update33.v1

## Required folder and path layout

The following paths come from the approved setup contract. They are target locations documented inside this downloadable setup deliverable; Courseware Studio does not create or write to these folders on the user's machine.

| Field | Value |
|---|---|
| Root setup folder | C:\Classfiles\ |
| Class files folder | C:\Classfiles\Classfiles |
| Downloads/installers folder | C:\Classfiles\Downloads |
| Lab files folder | C:\Classfiles\Labs |
| Scripts folder | C:\Classfiles\Scripts |
| Validation logs folder | C:\Classfiles\ValidationLogs |
| Docker project folder | — |
| Docker volume/mount path | — |
| Hyper-V VM folder | C:\Hyper-V\55318B\VMs |
| Hyper-V checkpoint/export folder | C:\Hyper-V\55318B\Checkpoints |
| Guest OS class files path | C:\Classfiles |

## Path handling rules

- Place course files under the approved root and class files folders.
- Keep downloads/installers separate from lab files.
- Store validation evidence in the validation logs folder.
- Do not move Docker or Hyper-V resources to cloud locations as part of this local setup package.
