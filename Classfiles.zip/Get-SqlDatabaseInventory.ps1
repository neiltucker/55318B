<#
    Script: Get-SqlDatabaseInventory.ps1
    Description: Queries SQL Server instance and outputs inventory details.
#>

[CmdletBinding()]
param(
    [string]$ServerInstance = "localhost",
    [string]$OutputFile = "C:\Classfiles\DatabaseInventory.json"
)

Import-Module -Name "C:\Classfiles\ReportUtilities.psm1" -ErrorAction SilentlyContinue

Write-LogEntry -Message "Starting SQL Database Inventory for $ServerInstance..." -Level 'INFO'

try {
    $query = @"
SELECT 
    name AS DatabaseName,
    database_id AS DatabaseID,
    create_date AS CreateDate,
    state_desc AS State,
    recovery_model_desc AS RecoveryModel
FROM sys.databases
WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb');
"@

    if (Get-Command -Name "Invoke-Sqlcmd" -ErrorAction SilentlyContinue) {
        $inventory = Invoke-Sqlcmd -ServerInstance $ServerInstance -Query $query -TrustServerCertificate
    } else {
        $connectionString = "Server=$ServerInstance;Database=master;Integrated Security=True;TrustServerCertificate=True;"
        $connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
        $connection.Open()
        
        $command = $connection.CreateCommand()
        $command.CommandText = $query
        $adapter = New-Object System.Data.SqlClient.SqlDataAdapter($command)
        $dataset = New-Object System.Data.DataSet
        [void]$adapter.Fill($dataset)
        $connection.Close()
        
        $inventory = $dataset.Tables[0]
    }

    $inventory | ConvertTo-Json -Depth 3 | Out-File -FilePath $OutputFile -Encoding utf8
    Write-LogEntry -Message "Inventory saved to $OutputFile" -Level 'INFO'
}
catch {
    Write-LogEntry -Message "Error fetching SQL inventory: $_" -Level 'ERROR'
}
