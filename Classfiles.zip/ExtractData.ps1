<#
    Script: ExtractData.ps1
    Description: Data extraction script for lab workflow.
#>

[CmdletBinding()]
param(
    [string]$SourceCsv = "C:\Classfiles\TerritoryManagers.csv",
    [string]$OutputDir = "C:\Classfiles"
)

Import-Module "C:\Classfiles\ReportUtilities.psm1" -ErrorAction SilentlyContinue

Write-LogEntry -Message "Starting data extraction routine..." -Level 'INFO'

if (Test-Path $SourceCsv) {
    $data = Import-Csv $SourceCsv
    $cleaned = $data | Where-Object { $_.Region -ne "" }
    
    $outputPath = Join-Path $OutputDir "CleanedSales_STUDENT.json"
    $cleaned | ConvertTo-Json -Depth 2 | Out-File -FilePath $outputPath -Encoding utf8
    Write-LogEntry -Message "Cleaned sales/territory data saved to $outputPath" -Level 'INFO'
} else {
    Write-LogEntry -Message "Source CSV file not found: $SourceCsv" -Level 'WARNING'
}
