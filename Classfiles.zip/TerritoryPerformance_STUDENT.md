# Territory Performance Report - STUDENT

Generated on: 2026-08-05 08:00:00

| TerritoryID | TerritoryName | ManagerName | Region | Status |
| --- | --- | --- | --- | --- |
| 1 | Northeast | Sarah Jenkins | North America | Active |
| 2 | Northwest | Michael Chang | North America | Active |
| 3 | Central | David Ross | North America | Active |
| 4 | Southwest | Elena Gomez | North America | Active |
| 5 | Southeast | James Wilson | North America | Active |
| 6 | Europe West | Claire Dubois | Europe | Active |
| 7 | Pacific | Kenji Tanaka | Asia-Pacific | Active |
