<#
    Module: ReportUtilities.psm1
    Description: Shared utility functions for course 55318B automated reporting labs.
#>

function Write-LogEntry {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Message,

        [Parameter(Mandatory=$false)]
        [ValidateSet('INFO', 'WARNING', 'ERROR')]
        [string]$Level = 'INFO',

        [Parameter(Mandatory=$false)]
        [string]$Path = "C:\Classfiles\execution_log.txt"
    )

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logLine = "[$timestamp] [$Level] $Message"
    
    switch ($Level) {
        'ERROR'   { Write-Error $Message }
        'WARNING' { Write-Warning $Message }
        default   { Write-Host $logLine }
    }

    try {
        $logLine | Out-File -FilePath $Path -Append -Encoding utf8
    }
    catch {
        Write-Warning "Failed to write to log file: $_"
    }
}

function Export-MarkdownReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Title,

        [Parameter(Mandatory=$true)]
        [array]$Data,

        [Parameter(Mandatory=$true)]
        [string]$OutputPath
    )

    $sb = [System.Text.StringBuilder]::new()
    [void]$sb.AppendLine("# $Title")
    [void]$sb.AppendLine("Generated on: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
    [void]$sb.AppendLine("")

    if ($Data.Count -gt 0) {
        $props = $Data[0].PSObject.Properties.Name
        [void]$sb.AppendLine("| " + ($props -join " | ") + " |")
        
        $dividers = $props | ForEach-Object { "---" }
        [void]$sb.AppendLine("| " + ($dividers -join " | ") + " |")
        
        foreach ($item in $Data) {
            $rowValues = $props | ForEach-Object { $item.$_ }
            [void]$sb.AppendLine("| " + ($rowValues -join " | ") + " |")
        }
    } else {
        [void]$sb.AppendLine("*No data available.*")
    }

    $sb.ToString() | Out-File -FilePath $OutputPath -Encoding utf8
    Write-LogEntry -Message "Report successfully generated at $OutputPath" -Level 'INFO'
}

Export-ModuleMember -Function Write-LogEntry, Export-MarkdownReport
