<#
    Script: Get-UnifiedMetadata_STUDENT.ps1
    Description: Fetches and merges metadata from local JSON, CSV feeds, and REST endpoints.
#>

[CmdletBinding()]
param(
    [string]$ConfigPath = "C:\Classfiles\ReportConfig.json"
)

Import-Module "C:\Classfiles\ReportUtilities.psm1" -ErrorAction SilentlyContinue

if (-not (Test-Path $ConfigPath)) {
    Write-Error "Config file not found at $ConfigPath"
    exit 1
}

$config = Get-Content $ConfigPath | ConvertFrom-Json
Write-LogEntry -Message "Loading unified metadata for student session..." -Level 'INFO'

$mockPath = "C:\Classfiles\mock_metadata.json"
$mockData = if (Test-Path $mockPath) { Get-Content $mockPath | ConvertFrom-Json } else { @() }

$csvPath = "C:\Classfiles\TerritoryManagers.csv"
$territoryData = if (Test-Path $csvPath) { Import-Csv $csvPath } else { @() }

Write-Host "Loaded $($mockData.Count) server entries and $($territoryData.Count) territory managers."

$unified = [PSCustomObject]@{
    Timestamp     = Get-Date
    ServerCount   = $mockData.Count
    Territories   = $territoryData.Count
    ConfigVersion = $config.Version
}

$unified | Format-List
