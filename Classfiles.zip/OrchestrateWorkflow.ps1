<#
    Script: OrchestrateWorkflow.ps1
    Description: Orchestrates data extraction, metadata integration, and report generation.
#>

[CmdletBinding()]
param(
    [string]$Initials = "STUDENT"
)

$scriptDir = "C:\Classfiles"
Import-Module "$scriptDir\ReportUtilities.psm1" -ErrorAction Stop

Write-LogEntry -Message "=== Orchestration Started for Learner: $Initials ===" -Level 'INFO'

Write-LogEntry -Message "Executing Step 1: ExtractData.ps1" -Level 'INFO'
& "$scriptDir\ExtractData.ps1"

Write-LogEntry -Message "Executing Step 2: Get-UnifiedMetadata_$Initials.ps1" -Level 'INFO'
$unifiedScript = "$scriptDir\Get-UnifiedMetadata_$Initials.ps1"
if (Test-Path $unifiedScript) {
    & $unifiedScript
} else {
    & "$scriptDir\Get-UnifiedMetadata_STUDENT.ps1"
}

$reportPath = "$scriptDir\StatusReport_$Initials.md"
$sampleData = @(
    [PSCustomObject]@{ Task = "SQL Inventory"; Status = "Completed"; Timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm") },
    [PSCustomObject]@{ Task = "Data Cleaning"; Status = "Completed"; Timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm") },
    [PSCustomObject]@{ Task = "Report Compilation"; Status = "In Progress"; Timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm") }
)

Export-MarkdownReport -Title "Workflow Execution Status - $Initials" -Data $sampleData -OutputPath $reportPath

Write-LogEntry -Message "=== Orchestration Complete ===" -Level 'INFO'
